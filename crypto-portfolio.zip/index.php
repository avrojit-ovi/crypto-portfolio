<?php
require_once('database.php');
// Redirect to fetchdata.php
header("Location: {$baseurl}fetchdata.php");
exit();
?>